# Particle detection > 2023-10-07 1:55pm
https://universe.roboflow.com/mihail-kulik-qswwx/particle-detection-midjk

Provided by a Roboflow user
License: Public Domain

